<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/sbadmin/bower_components/bootstrap/dist/css/bootstrap.min.css" media="screen">
<!--<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/sbadmin/bower_components/bootstrap/dist/css/bootstrap-theme.css">-->
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/sbadmin/bower_components/metisMenu/dist/metisMenu.min.css">
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/sbadmin/dist/css/sb-admin-2.css">
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/sbadmin/bower_components/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/css/daterangepicker-bs3.css">
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/css/bootstrap-select.min.css">
<link rel="stylesheet" href="<?=$this->config->item('base_url')?>r_/css/comun.css">