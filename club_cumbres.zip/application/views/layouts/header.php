<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?=TITULO?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<?=$include_css?>
		<script>var _sitePath_ = '<?=base()?>'; var _suffix_ = '<?=suffix()?>';</script>
		<?=$include_js?>
  </head>
  <body>