<script src="<?=$this->config->item('base_url')?>r_/js/require.js"></script>
<script src="<?=$this->config->item('base_url')?>r_/js/require_paths.js"></script>
<script src="<?=$this->config->item('base_url')?>r_/js/jquery-1.11.2.min.js"></script>