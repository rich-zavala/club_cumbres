$().ready(function(){
		
	//Eventos de eliminación
	$('.btn-eliminar').each(function(){
		eliminar($(this));
	});
});